function welcome() {
    console.log("Hello, World!");
}

welcome();