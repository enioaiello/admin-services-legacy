# Création d'une application pour Admin Services
## Introduction
Bonjour à vous, développeur !
Vous voulez concevoir une application pour **Admin Services** ? Vous êtes au bon endroit ! Avant de commencer à mettre les mains au clavier, lisez l'entièreté de ce fichier. Ce fichier comporte les instructions et les étapes essentiels pour le développement de votre logiciel/jeu !\
Avant d'aller plus loin, vérifiez que vous **avez la dernière version de votre compte**. Vous ne savez pas ? Pas un soucis ! Ouvrez les **paramètres de compte** d'**Admin Services** puis mettez à niveau votre compte ! Ensuite, vérifiez que l'idée de votre application n'a pas été déjà emprunté. Bien, commençons !
## Ressources
Voici les règles pour développer une application :
- Elle doit être compatible **GitHub Pages**, donc, selon leurs limitations, aucunes bases de données, malheureusement.
- Elle doit être contenue dans **un seul fichier** : le code JavaScript y compris.
- Vous avez le droit de pointer vos propres ressources sur votre propre serveur, comme des images, des scripts...
- Indiquez toujours, lorsque vous arrivez sur votre application et si c'est le cas, que cette dernière utilise les informations des utilisateurs. Vous avez également la permission de rajouter un bouton pour fermer le pop-up définitivement.
- Vous avez le droit d'utiliser les localStorage, le localStorage doit être représenté comme : `[nom de votre application].[nom du développeur].[nom du localStorage]`. Si cela n'a pas été respecté, nous nous réservons le droit de refuser l'intégration de votre application.
- Si des ressources externes sont ajoutées (hors image), merci de prévenir l'utilisateur que vous quittez la page, assurez-vous que redirigez bien l'utilisateur dans un nouvel onglet.
- Si votre application est "externe" (cela signifie qu'il s'agit uniquement d'un lien vrs votre application) précisez-le dans le formulaire en __indiquant le lien__. Car quand cette application va être soumise à **Admin Services** elle ne sera qu'un lien vers votre application. Au cas où vous ne l'auriez pas compris, une application "interne" est stockée localement chez **GitHub** avec toutes les limitations, si elle est "externe" elle redirigera autre part.
- Si votre application nécessite une condition d'utilisation, indiquez-le dans le formulaire et rajoutez un lien dans votre application.
- Ajoutez un lien pour revenir sur **Admin Services**.
- Modifiez la lience afin qu'elle corresponde à l'année de développement de votre application et au nom de l'application.
## Envoie de l'application
Envoyez votre application à l'adresse e-mail suivante `aielloenio@icloud.com`, en mettant un repository **GitHub** (sans lien raccourcis s'il-vous-plaît !). Le lien **GitHub** doit ressembler à ça : `https://github.com/[votre-pseudo]/[nom-repository]`. Si cela n'est pas respecté, le mail sera classé comme pourriel.
À noter que :
- Votre repository GitHub doit être **publique**.
- Votre repository comporte ce dossier **compressé** (zip uniquement) avec les instructions (ce fichier) complété.
## Mon application
> Remplissez le formulaire pour expliquer de quoi traite votre application. Toutes les questions sont obligatoires.
- **Nom de l'application :**
- **Description de l'application :**
- **Lien externe ?**
- **Conditions d'utilisations de l'application ?**
- **Taille de l'application (ne doit pas dépasser les 500 Mo) ?**
## Dernières ressources
**Votre application doit respecter l'ensemble des utilisateurs.** Il est donc interdit de :
- Mettre des discours discriminatoire.
- Mettre des propos racistes, homophobiques, sexistes...
- Mettre des images clignotantes.
Il est, au contrairement, nécessaire de :
- Respecter la vie privée des utilisateurs
- Respecter les loi en vigueur du pays : France
- Vous avez l'autorisation de mettre plusieurs langues ou des langages différents.
## Remerciements
- **Enio Aiello :** créateur d'**Admin Services** et **Corundum**.
- **Team Corundum :** mise en place de ce site.
- **GitHub :** hébergeur d'**Admin Services**.