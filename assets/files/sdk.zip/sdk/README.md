# SDK d'Admin Services

Ce SDK fournit une interface pour proposer votre application Admin Services. Vous devez fournir un code écrit en HTML, CSS et JavaScript.

## Optimisation du code

Le code de ce SDK doit être optimisé pour assurer des performances optimales auprès de **GitHub Pages**. Veuillez également respecter les nouvelles normes.

## Compatibilité avec GitHub Pages

Votre application doit être compatible avec GitHub Pages, ce qui signifie qu'il ne doit pas y avoir de langages côtés back-end.

## Licence

Nous vous recommandons d'indiquer une licence de type **MIT**. Veuillez créer un fichier LICENSE pour l'appliquer.

## Structure des dossiers

- `assets/css` : Ce dossier contient les fichiers CSS utilisés par le SDK.
- `assets/img` : Ce dossier contient les images utilisées par le SDK.
- `assets/js` : Ce dossier contient les fichiers JavaScript utilisés par le SDK.

## Sécurité et confidentialités

Votre application peut utiliser, créer, modifier ou supprimer les différents **localStorage** intégrés. Cependant vous ne devez pas modifier les paramètres ou les données de l'utilisateur sans consetement. Si vous développez une application lié à la sécurité de l'utilisateur pour **Admin Services**, merci de remplir le formulaire présent dans le dossier `publication`, à la racine de ce SDK.

### Note pour Admin Services 10

Votre application ne pourrait pas fonctionner sur **Admin Services 10** si celle-ci modifie des paramètres de sécurité tels que la sécurité au démarrage, la protection contre la réécriture de données ou autre. Nous vous conseillons donc d'utiliser uniquement les données utilisateurs basiques, tels qu'une photo de profil, un nom d'utilisateur...

## Règles de publication

1. Votre application doit être accessible : compatible PC, tablette, téléphone, adaptée aux outils d'accessibilité intégré sur l'OS de l'utilisateur
2. Votre application peut désormais contenir des ressources directement sur **Admin Services** (plus besoin de serveur externe)
3. Avant l'envoi de l'application, remplissez les formulaires nécessaire dans `publication`
4. Vous devez fournir un lien dans votre application pour retourner à l'accueil d'**Admin Services**, la bibliothèque d'applications ou l'écran de connexion
5. Vous pouvez utiliser la version **grand publique** d'**ArticlesUI** si vous en avez besoin
6. (Optionnel) Dans le dossier `publication`, remplissez le formulaire `login-dev.md` pour obtenir un accès développeur dés la publication de votre application

## Ressources

> Dernière mise à jour des ressources le 18 mars 2024

- [Version grand publique d'**ArticlesUI**](https://github.com/Corundum-project/articlesui)
- [Lien d'accès à la version Web d'**Admin Services**](https://enioaiello.github.io/admin-services/)