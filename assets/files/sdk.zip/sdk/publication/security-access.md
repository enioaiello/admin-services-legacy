# SDK d'Admin Services

Ne remplissez ce formulaire que lorsque vous avez besoin d'accéder à certaines ressources du système de sécurité. Les réponses par défaut sont "non", vous pouvez donc ignorer les questions qui ne vous intéresse pas. Dans le cas contraire indiquez "oui". Toutes applications enfreignant la loi, ou violant les données des utlisateurs sera automatiquement refusé. Cela s'applique également aux applications malveillantes.

> Attention ! Si vous remplissez ce formulaire votre application sera automatiquement attribuée à la version 10 d'**Admin Services** !

## Formulaire

- **Accès au mot de passe de l'utilisateur :**
- **Modification du système de redirection :**
- **Modification du comportement du système de sécurité (au démarrage) :**
- **Accès ou modification de Fast-reconnect :**
- **Gérer les utilisateurs :**

## Assistance

- **Accès au mot de passe de l'utilisateur :** Autorise votre programme à accéder au mot de passe utilisateur, pour faire un système de protection ou une vérification par exemple
- **Modification du système de redirection :** Autorise votre programme à consulter et modifier le système de redirection. Celui-ci permet de rediriger vers **Admin Services**, **google-fake-admin-panel** ou autre
- **Modification du comportement du système de sécurité (au démarrage) :** Permet d'activer ou de désactiver le système de sécurité général ainsi que les sauvegardes utilisateurs
- **Accès ou modification de Fast-reconnect :** Permet de consulter ou d'activer/désactiver **Fast-reconnect** si l'utilisateur est connecté
- **Gérer les utilisateurs :** Permet de consulter et remplacer toutes les informations liés à la sécurité et à la connexion des utilisateurs, tels qu'une adresse email, un mot de passe...