# SDK d'Admin Services

Merci de **remplir** ce document **avant l'envoi**. Votre demande ne pourra pas être acceptée en cas contraire.

## Formulaire

- **Nom de l'application :**
- **Développeur de l'application :**
- **Type d'application :**
- **Cette application est externe :**
- **Dernière version compatible :**
- **Demande d'accès à la sécurité :**

## Assistance

- **Cette application est externe :** Indique que l'application sera intégrée sous forme de lien, et non comme réel application. Ce lien sera identique aux autres applications mais redirigera l'utilisateur dans une nouvelle fenêtre
- **Dernère version compatible :** Dernière version requise pour l'éxécution (si votre application est externe, indiquez "dernière")
- **Demande d'accès à la sécurité :** Par défaut, vous n'avez pas besoin de remplir cette question, mais si votre application a besoin d'accéder à des localStorage importants liés à la sécurité de l'utilisateur (protection contre la réécriture des données, protection au démarrage, système de redirection, système de sauvegarde de l'utilisateur, mot de passe de l'utilisateur) indiquez-le (vous aurez besoin de remplir le fichier `security-access.md`)