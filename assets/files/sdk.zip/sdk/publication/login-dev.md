# Demande d'identifiant

Permet aux développeurs qui le souhaitent, d'avoir un accès supplémentaire sur **Admin Services**. Cela ne requiert plus de compte inscrit (utilisateurs basiques).

> Attention ! Ne mettez pas de mots de passe existants, utilisez un mot de passe généré ou unique. Sachez que tous les utilisateurs peuvent consulter vos informations de connexion.

## Formulaire

- **Nom d'utilisateur :**
- **Adresse email :**
- **Mot de passe :**
- **Photo de profil (optionnel) :**